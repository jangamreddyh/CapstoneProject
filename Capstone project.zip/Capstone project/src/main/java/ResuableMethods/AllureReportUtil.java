//package ResuableMethods;
//
//import java.io.*;
//import java.nio.file.Files;
//import java.nio.file.StandardCopyOption;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//public class AllureReportUtil {
//    public static void cleanAllureResults() {
//        cleanDirectory("allure-results");
//        cleanDirectory("allure-report");
//    }
//    private static void cleanDirectory(String dirPath) {
//        File dir = new File(dirPath);
//        if (dir.exists()) {
//            for (File file : dir.listFiles()) {
//                if (!file.isDirectory()) {
//                    file.delete();
//                }
//            }
//            System.out.println("Cleaned directory: " + dirPath);
//        }
//    }
//    public static void generateAllureReport() throws IOException, InterruptedException {
//        String allureResultsDir = "allure-results";
//        String allureReportDir = "allure-report";
//        String allureBinDir = "./allure-2.32.0/bin/allure.bat";
//        String timestamp = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date());
//        String reportFileName = "index_" + timestamp + ".html";
//        String archivedReportsDir = "archived-reports";
//        File archiveDir = new File(archivedReportsDir);
//        if (!archiveDir.exists()) {
//            boolean created = archiveDir.mkdirs();
//            if (created) {
//                System.out.println("Archived reports folder created at: " + archivedReportsDir);
//            } else {
//                System.out.println("Archived reports folder already exists or failed to create.");
//            }
//        }
//
//        List<String> command = new ArrayList<>();
//        command.add(allureBinDir);
//        command.add("generate");
//        command.add(allureResultsDir);
//        command.add("--output");
//        command.add(allureReportDir);
//        command.add("--single-file");
//        ProcessBuilder processBuilder = new ProcessBuilder(command);
//        processBuilder.inheritIO();
//        Process process = processBuilder.start();
//        InputStream errorStream = process.getErrorStream();
//        BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream));
//        String line;
//        while ((line = reader.readLine()) != null) {
//            System.out.println("ERROR: " + line);
//        }
//        int exitCode = process.waitFor();
//        if (exitCode == 0) {
//            copyReportToArchive(allureReportDir, archivedReportsDir, reportFileName);
//            System.out.println("Allure report generated successfully at: " + allureReportDir);
//        } else {
//            System.out.println("Failed to generate Allure report.");
//        }
//    }
//    private static void copyReportToArchive(String allureReportDir, String archivedReportsDir, String reportFileName) {
//        File originalFile = new File(allureReportDir + "/index.html");
//        File copiedFile = new File(archivedReportsDir + "/" + reportFileName);
//
//        if (originalFile.exists()) {
//            try {
//                Files.copy(originalFile.toPath(), copiedFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
//                System.out.println("Report copied to: " + copiedFile.getAbsolutePath());
//            } catch (IOException e) {
//                System.out.println("Failed to copy the report to the archived folder.");
//                e.printStackTrace();
//            }
//        } else {
//            System.out.println("Original report file not found.");
//        }
//    }
//}
